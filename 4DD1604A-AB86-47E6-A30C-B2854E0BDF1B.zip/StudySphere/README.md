# StudySphere

A three-page static website for a fictional study-resources platform, built with HTML, CSS, and vanilla JavaScript. Originally created as a final project in December 2023 and cleaned up in 2026 for my portfolio.

## Pages

| Page | File | What it does |
|---|---|---|
| Home | `index.html` | Overview of the site with an auto-rotating image slideshow |
| About Us | `about.html` | Background on the site with a typewriter animation on the title |
| Contact | `contact.html` | Contact form with client-side validation and feedback messages |

## Features

- **Shared stylesheet** (`styles.css`) so all three pages use one consistent theme
- **Navigation bar** on every page, with the current page highlighted
- **JavaScript slideshow** that rotates three slides every 3 seconds
- **Typewriter text animation** on the About page
- **Form validation** that checks for empty fields and a valid email format before showing a success message

## How to run

No build step or server is needed. Download the folder and open `index.html` in a browser.

## Notes

- The contact form is a front-end demo. It validates input but does not send data anywhere.
- StudySphere is a fictional site made for coursework.

## Author

Marlon Adadey
